gistpull
========

Chrome Extension (content script) to find and replace gist links with the embeded version.